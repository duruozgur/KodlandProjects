import os
from model import get_class

from dotenv import load_dotenv

load_dotenv()

TOKEN = os.environ.get("DISCORD_TOKEN")
CURRENCY_API_TOKEN = os.environ["CURRENCY_TOKEN"]

import discord
from discord.ext import commands, tasks

import requests
currency_headers = {"apikey": CURRENCY_API_TOKEN}
currency_url = "https://api.currencyapi.com/v3/latest"

intents = discord.Intents.all()
bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_ready():
    print(f'{bot.user.name} is logged in with style')
    send_dollar_update.start()
    
@bot.event
async def on_message(message):
    if message.author == bot.user:
        return
    if message.content.startswith("hello"):
        await message.channel.send("hello pitiful human")
    await bot.process_commands(message)
    
# or @commands.command
@bot.command(name="flag")
async def test(ctx, country):  # You can also use ctx, *, arg1 to capture the entire message after the command
    await ctx.send(f"https://flagsapi.com/{country.upper()}/flat/64.png")
    
@tasks.loop(seconds = 150 * 60)
async def send_dollar_update():
    response = requests.get(currency_url, headers = currency_headers)
    all_data = response.json()
    try_data = all_data["data"]["TRY"]["value"]
    
    for guild in bot.guilds:
        text_channels = guild.text_channels
        for channel in text_channels:
            await channel.send(f"TL / Dolar: {try_data}")
    
@bot.command("define")
async def define(ctx):
    if ctx.message.attachments:
        for attachment in ctx.message.attachments:
            file_name = attachment.filename
            file_url = attachment.url
            await attachment.save(f"./{attachment.filename}")
            await ctx.send(get_class(model_path="./keras_model.h5",
                                      labels_path="./labels.txt",
                                      image_path=f"./{attachment.filename}"))
    else:
        await ctx.send("You didnt attach any image")
    
bot.run(TOKEN)