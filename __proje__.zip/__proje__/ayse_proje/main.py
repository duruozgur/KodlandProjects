from flask import Flask, render_template, request
from flask_sqlalchemy import SQLAlchemy


app = Flask(__name__)
app.config["SECRET_KEY"] = "secret_key"
app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///database.db"

db = SQLAlchemy()
db.init_app(app)

class Note(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(50), nullable = False)
    text = db.Column(db.String(250), nullable = True)

@app.route("/", methods=["GET","POST"])
def home():
    if request.method == "GET":
        return render_template("index.html")
    else:
        title = request.form.get("title")
        note = request.form["note"]
        new_note = Note(title = title, text = note)
        db.session.add(new_note)
        db.session.commit()
        return render_template("index.html")

@app.route("/about")
def about():
    db_data = Note.query.all()
    return render_template("about.html", notes=db_data)

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)