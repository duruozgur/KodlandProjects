import speech_recognition as sr 

def speech_tr():
    mic = sr.Microphone()
    recog = sr.Recognizer()
    
    with mic as audio:
        print("Konusun...")
        
        recog.adjust_for_ambient_noise(audio)
        voice = recog.listen(audio)
        
        print("yazıya dönüştürülüyor...")
        return recog.recognize_google(voice, language = "tr-TR")
    
def speech_en():
    mic = sr.Microphone
    recog = sr.Recognizer
    
    with mic as audio:
        print("Konusun...")
        
        recog.adjust_for_ambient_noise(audio)
        voice = recog.listen(audio, 5, 4)
        
        print("yazıya dönüştürülüyor...")
        return recog.recognize_google(voice, language = "en-GB")
    