from tkinter import *
from speech import speech_tr
from tkinter import messagebox

window = Tk()

window.title("Bizim ilk uygulamamız")
window.minsize(350,350)

text = Label(window, text = "aa")
text.pack()

def yaziya_dok():
    try:
        konusulan = speech_tr()
    except:
        konusulan = "ne dedin anlamadım(error)"
    finally:
        print("oh be şükür")
        message = messagebox.showinfo("Söylediklerin:", konusulan)

button = Button(window, text = "Konusmaya başla", command = yaziya_dok)
button.pack()

window.mainloop()