from speech import speech_en
import random

seviyeler = {
    "kolay": ["cat", "car", "hello"],
    "orta": ["career", "ambulance", "knight"],
    "zor": ["procrastination", "pronounciation", "worcestershire", "antidisestablishmentarianism","Onomatopoeia"]
}

def game(level):
    kelime = random.choice(seviyeler[level])
    print(f"bunu söyle {kelime}")
    konusulan = speech_en
    
    if konusulan == kelime:
        print("Aferin")
    else:
        print(":(")
        
seviye = input("seviyeni gir (kolay,orta,zor)").lower
_seviyeler = ["kolay","orta","zor"]

if not seviye in _seviyeler:
    seviye = "zor"
    
game(seviye)