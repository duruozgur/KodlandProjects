#settings.py in original

ayarlar = {
    "on_taki": ">", #ön takı, prefix (maybe it won't work if we call it different here)
    "TOKEN": "MTE0NDcxNjY2NDExODcxODU1NA.Ge2nss.5QGukMyawpQxtk9921TwHdkAyoEYBj0wuPdQx0"
}