from flask import Flask
import random

app = Flask(__name__)

@app.route("/")
def home():
    return "<a>hello world</a>"

y_t = ["yazı","tura"]
a = random.choice(y_t)

@app.route("/helloworld")
def helloworld():
    return "<p>a</p>"

app.run(debug=True)

