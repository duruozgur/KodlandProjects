#settings.py in original

ayarlar = {
    "on_taki": ">", #ön takı, prefix (maybe it won't work if we call it different here)
    "TOKEN": "MTE0NDcxNjY2NDExODcxODU1NA.GDi5th.1LZUk8LdruhHvS8CrrYORDVUzAEm_3Pk6ZccQk"
}