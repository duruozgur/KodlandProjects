import random
import time

print(":D")

name=""

while len(name)==0:
    name=input("Enter your name: ")

print("Hi",name)

inventory = ["axe", "triangle key"]
coins = 100

print("İf you wanna see your inventory and coins , type 'show_usable'.")
time.sleep(0.7)

def show():
    print("inventory:",inventory)
    time.sleep(0.5)
    print("coins:",coins)

ans= input("comand box:")
if ans == "show_usable":
    show()