import random
from typing import Any

a = ["pasta", "suspicious stew", "spider eye", "cooked chicken", "golden carrot", "golden apple", "cooked stew"]

def get_response(message: str) -> str | tuple[str, Any, str]:
    b = random.choice(a)
    p_message = message.lower()

    if p_message == "hello":
        return "hi :3"

    if message == "roll":
        return str(random.randint(1,20))

    if p_message == "!help":
        return "`if you type '!food' i can cook something for you. (and where does the food come from? nobody knows.)`"

    if p_message == "!food":
        return "here, have your",b,":3"

    return "`i didn\'t understood what you wrote :( try typing !help.`"