from flask import Flask, render_template, redirect, request
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import pytz

app = Flask(__name__)
# SQLite'ı bağlama
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///diary.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
# Veri tabanı oluşturma
db = SQLAlchemy(app)

class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user = db.Column(db.String(100), nullable=False)
    comment = db.Column(db.String(300), nullable=False)
    date = db.Column(db.DateTime, default=lambda: datetime.now(pytz.timezone('Europe/Istanbul')), nullable=False)

@app.route("/", methods = ["POST", "GET"])
def home():
    if request.method == "GET":
        comments = Comment.query.order_by("id").all()
        return render_template("index.html" , comments = comments)
    else:
        user = request.form.get("user")
        comment = request.form("comment")
        new_comment = Comment(user = user, comment = comment)
        db.session.add(new_comment)
        db.session.commit()
        return render_template("index.html")


if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug = True)